const TIERS = { FREE: 0, PRO: 10, PRO_WEB: 20, PRO_WEB_ALERTS: 30 };
let userLevel = 0;

document.addEventListener("DOMContentLoaded", () => {
  // Load license first, then data
  chrome.runtime.sendMessage({ type: "GET_LICENSE" }, (resp) => {
    userLevel = resp?.license?.level || 0;
    loadData();
    renderLicenseSection(resp?.license);
  });

  // Check for updates
  checkForUpdate();

  // Tab switching
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;
      document.querySelectorAll(".tab-btn").forEach((b) => {
        b.classList.toggle("active", b === btn);
      });
      document.querySelectorAll(".tab-panel").forEach((p) => {
        p.style.display = p.id === `tab-${target}` ? "" : "none";
      });
      if (target === "alerts") renderAlertsTab();
    });
  });

  // Listen for live updates from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "DATA_UPDATED") {
      loadData();
    }
    if (message.type === "SCAN_PROGRESS") {
      updateScanProgress(message.performanceId, message.completed, message.total, message.status, message.eta);
    }
    if (message.type === "LICENSE_CHANGED") {
      chrome.runtime.sendMessage({ type: "GET_LICENSE" }, (resp) => {
        userLevel = resp?.license?.level || 0;
        renderLicenseSection(resp?.license);
        lastMatchName = null;
        loadData();
      });
    }
  });

  // Block toggle
  document.getElementById("blockToggle").addEventListener("click", () => {
    const body = document.getElementById("blockBody");
    const chevron = document.querySelector("#blockToggle .chevron");
    const isOpen = body.style.display !== "none";
    body.style.display = isOpen ? "none" : "block";
    chevron.classList.toggle("open", !isOpen);
  });

  // License toggle
  document.getElementById("licenseToggle").addEventListener("click", () => {
    const body = document.getElementById("licenseBody");
    const chevron = document.querySelector("#licenseToggle .chevron");
    const isOpen = body.style.display !== "none";
    body.style.display = isOpen ? "none" : "block";
    chevron.classList.toggle("open", !isOpen);
  });

  // Scan all sections
  document.getElementById("scanBtn").addEventListener("click", startScan);

  // Export CSV
  document.getElementById("exportBtn").addEventListener("click", exportCSV);

  // Clear data
  document.getElementById("clearBtn").addEventListener("click", () => {
    if (confirm("Clear all captured data?")) {
      chrome.runtime.sendMessage({ type: "CLEAR_DATA" }, () => {
        loadData();
      });
    }
  });

});

async function getCurrentTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab?.url || "";
  } catch { return ""; }
}

function loadData() {
  getCurrentTabUrl().then((url) => {
    const isFifaSite = /\.tickets\.fifa\.com/.test(url);
    const isSeatMap = isFifaSite && (/perfId=/.test(url) || /\/seat\//.test(url) || /\/performance\/\d+/.test(url));

    chrome.storage.local.get(null, (data) => {
      if (chrome.runtime.lastError || !data?.games) {
        showEmpty(isFifaSite, isSeatMap);
        return;
      }

      const games = data.games;
      const gameIds = Object.keys(games);

      if (gameIds.length === 0) {
        showEmpty(isFifaSite, isSeatMap);
        return;
      }

      // Match game to active tab's perfId, fallback to first game
      // Match perfId from query string (?perfId=123) or path (/performance/123/)
      const perfIdMatch = url.match(/perfId=(\d+)/) || url.match(/\/performance\/(\d+)/);
      const tabPerfId = perfIdMatch ? perfIdMatch[1] : null;
      const activeId = (tabPerfId && games[tabPerfId]) ? tabPerfId : gameIds[0];
      const game = games[activeId];

      if (!game || Object.keys(game.seats || {}).length === 0) {
        showEmpty(isFifaSite, isSeatMap);
        return;
      }

      // Restore persisted filters
      if (data.filters) {
        activeCatIndex = data.filters.activeCatIndex ?? -1;
        selectedTogether = new Set(data.filters.selectedTogether ?? [1, 2, 3, 4, 5, 6]);
      }

      currentPerfId = activeId;
      renderDashboard(game);
    });
  });
}

function showEmpty(isFifaSite, isSeatMap) {
  document.getElementById("noData").style.display = "block";
  document.getElementById("dashboard").style.display = "none";
  document.getElementById("liveBadge").style.display = "none";

  const title = document.getElementById("emptyTitle");
  const hint = document.getElementById("emptyHint");
  const action = document.getElementById("emptyAction");
  const scanningHelp = document.getElementById("scanningHelp");

  if (isSeatMap) {
    title.textContent = "Scanning\u2026";
    hint.textContent = "Capturing seat data from the map. This usually takes a few seconds.";
    action.style.display = "none";
    scanningHelp.style.display = "block";
  } else if (isFifaSite) {
    title.textContent = "Open a seat map";
    hint.textContent = "You\u2019re on the FIFA ticket site \u2014 select a match and open its seat map to start capturing prices.";
    action.style.display = "none";
    scanningHelp.style.display = "none";
  } else {
    title.textContent = "FIFA Ticket Scout";
    hint.textContent = "Open the FIFA resale ticket site and browse a seat map to start capturing prices.";
    action.textContent = "Open FIFA Resale Site";
    action.style.display = "";
    action.onclick = (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: "https://fwc26-resale-usd.tickets.fifa.com" });
    };
    scanningHelp.style.display = "none";
  }
}

function renderDashboard(game) {
  document.getElementById("noData").style.display = "none";
  document.getElementById("dashboard").style.display = "block";
  document.getElementById("liveBadge").style.display = "inline-flex";

  const seats = Object.values(game.seats || {}).filter(s => s.exclusive !== false && s.price != null);
  const match = game.match;

  renderMatchInfo(match);
  renderStatsBar(seats);
  renderCategorySections(seats);
  renderBlockTable(seats);
}

// --- Match Info ---

function scanSpeedHtml() {
  const locked = userLevel < TIERS.PRO;
  const lock = '<span class="lock-icon">&#x1F512;</span>';

  function speedBtn(speed, emoji, title) {
    const isLocked = locked && speed !== "balanced";
    const cls = isLocked ? "speed-btn locked" : "speed-btn";
    const suffix = isLocked ? " (Pro)" : "";
    return `<button class="${cls}" data-speed="${speed}" title="${title}${suffix}">${emoji}${isLocked ? lock : ""}</button>`;
  }

  return `<div class="scan-speed-container">
    <span class="scan-speed-title">Scan</span>
    <div class="scan-speed-btns" id="scanSpeedBtns">
      ${speedBtn("stealth", "&#x1F422;", "Stealth &#8212; Looks like a human casually browsing. Lowest detection risk.")}
      ${speedBtn("cautious", "&#x1F6B6;", "Cautious &#8212; Slower, good for accounts with tickets you can't afford to lose.")}
      ${speedBtn("balanced", "&#x2696;&#xFE0F;", "Balanced &#8212; Good mix of speed and safety. Recommended.")}
      ${speedBtn("aggressive", "&#x1F525;", "Aggressive &#8212; Fastest scan. Higher detection risk.")}
    </div>
    <div class="scan-pill" id="scanPill"><div class="scan-pill-bar"><div class="scan-pill-fill" id="scanPillFill"></div></div><span class="scan-pill-text" id="scanPillText"></span></div>
  </div>`;
}

let lastMatchName = null;

function renderMatchInfo(match) {
  const el = document.getElementById("matchInfo");

  // Skip re-render if match info hasn't changed (avoids pill/speed flicker)
  if (el.children.length > 0 && (match?.name ?? null) === lastMatchName) return;
  lastMatchName = match?.name ?? null;

  if (match?.name) {
    const parts = match.name.split(" / ");
    const matchNum = parts[1] || "";
    const teams = parts[2] || match.name;
    const venue = parts[3] || "";
    const date = match.date ? formatDate(match.date) : "";

    el.innerHTML = `
      <div class="match-top-row">
        <div class="match-teams">${escapeHtml(teams)}</div>
        ${scanSpeedHtml()}
      </div>
      <div class="match-meta">
        ${matchNum ? `<span>${escapeHtml(matchNum)}</span>` : ""}
        ${matchNum && venue ? `<span class="sep">&middot;</span>` : ""}
        ${venue ? `<span>${escapeHtml(venue)}</span>` : ""}
        ${(matchNum || venue) && date ? `<span class="sep">&middot;</span>` : ""}
        ${date ? `<span>${escapeHtml(date)}</span>` : ""}
      </div>
    `;
  } else {
    el.innerHTML = `
      <div class="match-top-row">
        <div class="match-teams">Match data loading&hellip;</div>
        ${scanSpeedHtml()}
      </div>
      <div class="match-meta">Browse the seat map to capture match info</div>
    `;
  }
  initSpeedButtons();
  restorePillProgress();
}

let lastPillPct = 0;
let scanStartTime = 0;
let scanElapsed = 0;
let currentPerfId = null;

function formatElapsed(ms) {
  const s = Math.round(ms / 1000);
  return Math.ceil(s / 2) * 2 + "s";
}

function restorePillProgress() {
  const fill = document.getElementById("scanPillFill");
  const text = document.getElementById("scanPillText");
  const pct = lastPillPct > 0 ? lastPillPct : 100;
  if (fill) fill.style.width = pct + "%";
  if (text && scanElapsed > 0) {
    text.textContent = formatElapsed(scanElapsed);
  }
}

// --- Stats Bar ---

let cachedScanSpeed = null;

function initSpeedButtons() {
  const container = document.getElementById("scanSpeedBtns");
  if (!container || container.dataset.listenersAttached) return;
  container.dataset.listenersAttached = "1";
  const btns = container.querySelectorAll(".speed-btn");
  const apply = (speed) => {
    btns.forEach((b) => b.classList.toggle("active", b.dataset.speed === speed));
  };
  if (cachedScanSpeed) {
    // Clamp if user was Pro but downgraded
    if (cachedScanSpeed !== "balanced" && userLevel < TIERS.PRO) {
      cachedScanSpeed = "balanced";
      chrome.storage.local.set({ scanSpeed: cachedScanSpeed });
    }
    apply(cachedScanSpeed);
  } else {
    chrome.storage.local.get("scanSpeed", (data) => {
      cachedScanSpeed = data.scanSpeed || "balanced";
      if (cachedScanSpeed !== "balanced" && userLevel < TIERS.PRO) {
        cachedScanSpeed = "balanced";
        chrome.storage.local.set({ scanSpeed: cachedScanSpeed });
      }
      apply(cachedScanSpeed);
    });
  }
  btns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const speed = btn.dataset.speed;

      // Gate non-balanced speeds behind Pro
      if (speed !== "balanced" && userLevel < TIERS.PRO) {
        const licenseBody = document.getElementById("licenseBody");
        const licenseToggle = document.getElementById("licenseToggle");
        if (licenseBody.style.display === "none") {
          licenseBody.style.display = "block";
          licenseToggle.querySelector(".chevron").classList.add("open");
        }
        document.getElementById("licenseSection").scrollIntoView({ behavior: "smooth" });
        const input = document.getElementById("licenseInput");
        if (input) {
          input.focus();
          input.classList.add("flash");
          setTimeout(() => input.classList.remove("flash"), 600);
        }
        return;
      }

      cachedScanSpeed = speed;
      apply(cachedScanSpeed);
      chrome.storage.local.set({ scanSpeed: cachedScanSpeed });
    });
  });
}

function renderStatsBar(seats) {
  const el = document.getElementById("statsBar");

  if (seats.length > 0) {
    const prices = seats.map((s) => centsToUSD(s.price));
    const min = Math.min(...prices);
    const max = Math.max(...prices);

    el.innerHTML = `
      <div class="stat">
        <div class="stat-value">${seats.length.toLocaleString()}</div>
        <div class="stat-label">Seats</div>
      </div>
      <div class="stat">
        <div class="stat-value">$${formatPrice(min)}</div>
        <div class="stat-label">Cheapest</div>
      </div>
      <div class="stat">
        <div class="stat-value">$${formatPrice(max)}</div>
        <div class="stat-label">Priciest</div>
      </div>
    `;
  } else {
    el.innerHTML = `
      <div class="stat">
        <div class="stat-value">0</div>
        <div class="stat-label">Seats</div>
      </div>
      <div class="stat">
        <div class="stat-value">&mdash;</div>
        <div class="stat-label">Cheapest</div>
      </div>
      <div class="stat">
        <div class="stat-value">&mdash;</div>
        <div class="stat-label">Priciest</div>
      </div>
    `;
  }
}

// --- Category Tabs with Distribution + Cheapest Clusters ---

let activeCatIndex = -1;
let currentCatData = [];

function saveFilters() {
  chrome.storage.local.set({ filters: { activeCatIndex, selectedTogether: [...selectedTogether] } });
}
let selectedTogether = new Set([1, 2, 3, 4, 5, 6]); // all ON by default

function renderCategorySections(seats) {
  const tabsEl = document.getElementById("catTabs");
  const contentEl = document.getElementById("catContent");

  // Group seats by category
  const groups = {};
  for (const s of seats) {
    const cat = s.category || "Unknown";
    if (!groups[cat]) groups[cat] = { seats: [], color: s.color };
    groups[cat].seats.push(s);
  }

  // Sort by seat count descending
  currentCatData = Object.entries(groups).sort((a, b) => {
    return b[1].seats.length - a[1].seats.length;
  });

  if (currentCatData.length === 0) {
    tabsEl.innerHTML = "";
    contentEl.innerHTML = "";
    return;
  }

  // Clamp active index (-1 = All)
  if (activeCatIndex >= currentCatData.length) activeCatIndex = -1;

  // Render tabs — "All" first, then categories by seat count
  const totalSeats = currentCatData.reduce((sum, [, d]) => sum + d.seats.length, 0);
  const allTab = `<button class="cat-tab ${activeCatIndex === -1 ? "active" : ""}" data-index="-1">
    All
    <span class="cat-tab-count">${totalSeats}</span>
  </button>`;

  const catTabs = currentCatData
    .map(([cat, data], i) => {
      const shortName = cat.replace("Category ", "Cat ");
      const dotColor = data.color || "#6b7588";
      return `<button class="cat-tab ${i === activeCatIndex ? "active" : ""}" data-index="${i}">
        <span class="category-dot" style="background:${dotColor}"></span>${escapeHtml(shortName)}
        <span class="cat-tab-count">${data.seats.length}</span>
      </button>`;
    })
    .join("");

  tabsEl.innerHTML = allTab + catTabs;

  // Tab click handlers
  tabsEl.querySelectorAll(".cat-tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      activeCatIndex = parseInt(btn.dataset.index);
      saveFilters();
      renderCategorySections(seats);
    });
  });

  // Render active category content
  let activeSeats, activeColor;
  if (activeCatIndex === -1) {
    // All categories combined
    activeSeats = currentCatData.flatMap(([, d]) => d.seats);
    activeColor = "#1a3d8f";
  } else {
    const [, data] = currentCatData[activeCatIndex];
    activeSeats = data.seats;
    activeColor = data.color || "#1a3d8f";
  }

  // Build clusters first so we can filter seats by "together" count
  const allClusters = buildAllClusters(activeSeats);
  const allOn = selectedTogether.size === 6;
  const filteredClusters = allOn
    ? allClusters
    : allClusters.filter((c) => {
        if (c.count >= 6) return selectedTogether.has(6);
        return selectedTogether.has(c.count);
      });

  // When filtering by together count, only use seats from qualifying clusters
  let displaySeats;
  if (!allOn) {
    const qualifyingKeys = new Set();
    for (const c of filteredClusters) {
      for (const s of c.seats) qualifyingKeys.add(seatKey(s));
    }
    displaySeats = activeSeats.filter((s) => qualifyingKeys.has(seatKey(s)));
  } else {
    displaySeats = activeSeats;
  }

  const prices = displaySeats.map((s) => centsToUSD(s.price));
  const sortedPrices = prices.slice().sort((a, b) => a - b);

  let statsHtml, histHtml;
  if (sortedPrices.length > 0) {
    const min = sortedPrices[0];
    const max = sortedPrices[sortedPrices.length - 1];
    const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
    const median = sortedPrices.length % 2 === 0
      ? (sortedPrices[sortedPrices.length / 2 - 1] + sortedPrices[sortedPrices.length / 2]) / 2
      : sortedPrices[Math.floor(sortedPrices.length / 2)];

    statsHtml = `
      <div class="cat-stats">
        <span class="cat-stat">
          <span class="cat-stat-label">Cheapest</span>
          <span class="price-green">$${formatPrice(min)}</span>
        </span>
        <span class="cat-stat">
          <span class="cat-stat-label">Median</span>
          <span class="price-white">$${formatPrice(median)}</span>
          <span class="price-avg">avg $${formatPrice(avg)}</span>
        </span>
        <span class="cat-stat">
          <span class="cat-stat-label">Highest</span>
          <span class="price-red">$${formatPrice(max)}</span>
        </span>
      </div>`;
    histHtml = buildDistribution(prices, activeColor);
  } else {
    statsHtml = `
      <div class="cat-stats">
        <span class="cat-stat">
          <span class="cat-stat-label">Cheapest</span>
          <span class="price-green">&mdash;</span>
        </span>
        <span class="cat-stat">
          <span class="cat-stat-label">Median</span>
          <span class="price-white">&mdash;</span>
        </span>
        <span class="cat-stat">
          <span class="cat-stat-label">Highest</span>
          <span class="price-red">&mdash;</span>
        </span>
      </div>`;
    histHtml = "";
  }

  const clustersHtml = renderClusterPage(filteredClusters, 0);

  const togetherBtns = [1, 2, 3, 4, 5, 6]
    .map((n) => {
      const label = n === 6 ? "6+" : String(n);
      const active = selectedTogether.has(n) ? "active" : "";
      return `<button class="together-btn ${active}" data-tog="${n}">${label}</button>`;
    })
    .join("");

  const seatCount = !allOn
    ? `<span class="together-count">${displaySeats.length} seats</span>`
    : "";

  contentEl.innerHTML = `
    <div class="together-filter">
      <span class="together-label">Seats together</span>
      <div class="together-btns">${togetherBtns}</div>
      ${seatCount}
    </div>
    ${statsHtml}
    ${histHtml}
    <div class="cheapest-header">
      Best Deals <span class="deals-count">${filteredClusters.length} groups</span>
    </div>
    <div id="clusterContainer">${clustersHtml}</div>
  `;

  // Together-filter click handlers
  contentEl.querySelectorAll(".together-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const n = parseInt(btn.dataset.tog);
      if (selectedTogether.has(n)) {
        selectedTogether.delete(n);
      } else {
        selectedTogether.add(n);
      }
      // If all toggled off, reset to all ON
      if (selectedTogether.size === 0) {
        selectedTogether = new Set([1, 2, 3, 4, 5, 6]);
      }
      saveFilters();
      renderCategorySections(seats);
    });
  });

  // Attach pagination handler
  attachClusterPagination(filteredClusters);
}

function buildDistribution(prices, color) {
  if (prices.length < 2) return "";

  const sorted = prices.slice().sort((a, b) => a - b);
  const totalSeats = sorted.length;

  // Bottom 80% get individual buckets, top 20% lumped together
  const cutoffIndex = Math.floor(totalSeats * 0.8);
  const mainPrices = sorted.slice(0, cutoffIndex);
  const tailPrices = sorted.slice(cutoffIndex);

  if (mainPrices.length < 2) return "";

  const mainMin = mainPrices[0];
  const mainMax = mainPrices[mainPrices.length - 1];
  const mainRange = mainMax - mainMin;

  if (mainRange === 0) return "";

  // Target ~20 bars for the main section, round bucket size to a clean number
  let rawBucketSize = mainRange / 20;
  // Round to nearest nice number: 50, 100, 250, 500, 1000, 2500, 5000
  const niceSteps = [25, 50, 100, 250, 500, 1000, 2500, 5000];
  let bucketSize = niceSteps.find((s) => s >= rawBucketSize) || rawBucketSize;

  const bucketStart = Math.floor(mainMin / bucketSize) * bucketSize;
  const mainBucketCount = Math.ceil((mainMax - bucketStart) / bucketSize) + 1;
  const totalBuckets = mainBucketCount + 1; // +1 for the tail bucket
  const buckets = new Array(totalBuckets).fill(0);

  for (const p of mainPrices) {
    let idx = Math.floor((p - bucketStart) / bucketSize);
    if (idx < 0) idx = 0;
    if (idx >= mainBucketCount) idx = mainBucketCount - 1;
    buckets[idx]++;
  }
  buckets[totalBuckets - 1] = tailPrices.length;

  const maxBucket = Math.max(...buckets);
  const tailMin = tailPrices.length > 0 ? tailPrices[0] : 0;
  const tailMax = tailPrices.length > 0 ? tailPrices[tailPrices.length - 1] : 0;

  const bars = buckets
    .map((count, i) => {
      const isTail = i === totalBuckets - 1;
      let label;
      if (isTail) {
        label = `$${formatPrice(tailMin)}-$${formatPrice(tailMax)}: ${count} seat${count !== 1 ? "s" : ""} (top 20%)`;
      } else {
        const lo = bucketStart + i * bucketSize;
        const hi = lo + bucketSize;
        label = `$${formatPrice(lo)}-$${formatPrice(hi)}: ${count} seat${count !== 1 ? "s" : ""}`;
      }

      if (count === 0) {
        return `<div class="hist-bar" title="${label}" style="height:1px;background:${color};opacity:0.08;"></div>`;
      }
      const height = Math.max(Math.round((count / maxBucket) * 100), 4);
      return `<div class="hist-bar" title="${label}" style="height:${height}%;background:${isTail ? "var(--text-muted)" : color};opacity:${isTail ? 0.5 : 0.8};"></div>`;
    })
    .join("");

  return `
    <div class="distribution">
      <div class="hist-chart">${bars}</div>
      <div class="hist-labels">
        <span>$${formatPrice(bucketStart)}</span>
        <span class="hist-total">${totalSeats} seats &middot; $${formatPrice(bucketSize)} bars</span>
        <span>top 20%</span>
      </div>
    </div>
  `;
}

function seatKey(s) { return s.seat + "_" + s.block + "_" + s.row; }

function buildAllClusters(seats) {
  const sorted = seats.slice().sort((a, b) => a.price - b.price);
  const clusters = [];
  const used = new Set();

  // Group seats by block+row+price for O(n) neighbor lookup
  const groupMap = new Map();
  for (const s of sorted) {
    const k = s.block + "_" + s.row + "_" + s.price;
    if (!groupMap.has(k)) groupMap.set(k, []);
    groupMap.get(k).push(s);
  }

  for (const seat of sorted) {
    if (used.has(seatKey(seat))) continue;

    const k = seat.block + "_" + seat.row + "_" + seat.price;
    const neighbors = groupMap.get(k).filter((s) => !used.has(seatKey(s)));

    neighbors.sort((a, b) =>
      a.seat.localeCompare(b.seat, undefined, { numeric: true })
    );

    // Find consecutive runs
    const consecutive = [neighbors[0]];
    for (let i = 1; i < neighbors.length; i++) {
      const prev = parseInt(neighbors[i - 1].seat);
      const curr = parseInt(neighbors[i].seat);
      if (curr === prev + 1) {
        consecutive.push(neighbors[i]);
      } else {
        break;
      }
    }

    for (const s of consecutive) {
      used.add(seatKey(s));
    }

    const seatNums = consecutive.map((s) => s.seat);
    const seatDisplay =
      seatNums.length === 1
        ? `Seat ${seatNums[0]}`
        : `Seats ${seatNums[0]}-${seatNums[seatNums.length - 1]}`;

    clusters.push({
      block: seat.block,
      row: seat.row,
      seatDisplay,
      count: consecutive.length,
      price: centsToUSD(seat.price),
      area: seat.area,
      seats: consecutive,
    });
  }

  return clusters;
}

const CLUSTERS_PER_PAGE = 10;

function renderClusterPage(clusters, page) {
  if (clusters.length === 0) return "<div class='no-deals'>No seats found</div>";

  const start = page * CLUSTERS_PER_PAGE;
  const pageItems = clusters.slice(start, start + CLUSTERS_PER_PAGE);
  const hasMore = start + CLUSTERS_PER_PAGE < clusters.length;
  const hasPrev = page > 0;
  const totalPages = Math.ceil(clusters.length / CLUSTERS_PER_PAGE);

  const rows = pageItems
    .map((c, i) => {
      const rank = start + i + 1;
      return `
      <div class="cluster-row">
        <div class="cluster-rank">${rank}</div>
        <div class="cluster-info">
          <div class="cluster-location">Block ${escapeHtml(c.block)} &middot; Row ${escapeHtml(c.row)} &middot; ${escapeHtml(c.seatDisplay)}</div>
          <div class="cluster-detail">${c.count > 1 ? c.count + " together" : "single seat"}${c.area ? " &middot; " + escapeHtml(c.area.length > 30 ? c.area.substring(0, 28) + "\u2026" : c.area) : ""}</div>
        </div>
        <div class="cluster-price">$${formatPrice(c.price)}${c.count > 1 ? "<span class='each'>ea</span>" : ""}</div>
      </div>`;
    })
    .join("");

  const pagination =
    totalPages > 1
      ? `<div class="cluster-pagination">
          <button class="page-btn" data-page="${page - 1}" ${hasPrev ? "" : "disabled"}>&#8592; Prev</button>
          <span class="page-info">${page + 1} / ${totalPages}</span>
          <button class="page-btn" data-page="${page + 1}" ${hasMore ? "" : "disabled"}>Next &#8594;</button>
        </div>`
      : "";

  return `<div class="clusters">${rows}</div>${pagination}`;
}

function attachClusterPagination(allClusters) {
  const container = document.getElementById("clusterContainer");
  if (!container) return;

  container.addEventListener("click", (e) => {
    const btn = e.target.closest(".page-btn");
    if (!btn || btn.disabled) return;
    const page = parseInt(btn.dataset.page);
    container.innerHTML = renderClusterPage(allClusters, page);
    attachClusterPagination(allClusters);
  });
}

// --- Block Table ---

function renderBlockTable(seats) {
  const tbody = document.querySelector("#blockTable tbody");

  const groups = {};
  for (const s of seats) {
    const key = s.block;
    if (!groups[key]) groups[key] = { area: s.area, prices: [] };
    groups[key].prices.push(centsToUSD(s.price));
  }

  const sorted = Object.entries(groups).sort((a, b) =>
    a[0].localeCompare(b[0], undefined, { numeric: true })
  );

  tbody.innerHTML = sorted
    .map(([block, data]) => {
      const min = Math.min(...data.prices);
      const max = Math.max(...data.prices);
      const areaDisplay =
        data.area.length > 26 ? data.area.substring(0, 24) + "\u2026" : data.area;

      return `<tr>
        <td>${escapeHtml(block)}</td>
        <td title="${escapeHtml(data.area)}">${escapeHtml(areaDisplay)}</td>
        <td class="num">${data.prices.length}</td>
        <td class="num price">$${formatPrice(min)}</td>
        <td class="num price">$${formatPrice(max)}</td>
      </tr>`;
    })
    .join("");
}


// --- Export CSV ---

function exportCSV() {
  chrome.storage.local.get(null, (data) => {
    if (!data?.games) return;

    const activeId = currentPerfId || Object.keys(data.games)[0];
    const game = data.games[activeId];
    if (!game) return;

    const seats = Object.values(game.seats || {}).filter(s => s.exclusive !== false && s.price != null);
    if (seats.length === 0) return;

    const match = game.match;
    const now = new Date();
    const exportTime = now.toISOString();

    const meta = [
      `# Match: ${match?.name || "Unknown"}`,
      `# Date: ${match?.date || "Unknown"}`,
      `# Currency: ${match?.currency || "USD"}`,
      `# Performance ID: ${activeId}`,
      `# Exported: ${exportTime}`,
      `# Total Seats: ${seats.length}`,
    ];

    const header = "Block,Area,Row,Seat,Category,Price_USD,Exclusive";
    const rows = seats
      .sort((a, b) => a.price - b.price)
      .map((s) => {
        const area = s.area.includes(",") ? `"${s.area}"` : s.area;
        return `${s.block},${area},${s.row},${s.seat},${s.category},${centsToUSD(s.price).toFixed(2)},${s.exclusive}`;
      });

    const csv = [...meta, "", header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    const matchName =
      game.match?.name?.replace(/[^a-zA-Z0-9]/g, "_") || "seats";
    const ts = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}`;
    const a = document.createElement("a");
    a.href = url;
    a.download = `${matchName}_${ts}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });
}

// --- Version Check ---

function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;
  fetch("https://raw.githubusercontent.com/david-dirring/fifa-ticket-scout/main/version.json")
    .then(r => r.json())
    .then(data => {
      if (data.latest && compareVersions(data.latest, current) > 0) {
        const banner = document.getElementById("updateBanner");
        if (banner) banner.style.display = "flex";
      }
    })
    .catch(() => {}); // silently fail
}

function compareVersions(a, b) {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

// --- Utilities ---

const FEE_MULTIPLIER = 1.15;
function centsToUSD(cents) { return cents / 1000 * FEE_MULTIPLIER; }

function formatPrice(n) {
  if (n >= 1000) {
    return n.toLocaleString("en-US", { maximumFractionDigits: 0 });
  }
  return n.toFixed(2);
}

function formatDate(dateStr) {
  // Input format: "15-06-2026 - 12:00"
  const m = dateStr.match(/(\d{2})-(\d{2})-(\d{4})\s*-\s*(\d{2}:\d{2})/);
  if (!m) return dateStr;
  const [, day, month, year, time] = m;
  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ];
  return `${months[parseInt(month) - 1]} ${parseInt(day)}, ${year} \u00B7 ${time}`;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// --- License UI ---

function renderLicenseSection(license) {
  const body = document.getElementById("licenseBody");
  const badge = document.getElementById("tierBadge");

  if (license && license.level > 0) {
    const tierName = license.level >= 30 ? "Pro + Alerts"
                   : license.level >= 20 ? "Pro + Web"
                   : "Scout Pro";
    badge.textContent = tierName;
    badge.className = "tier-badge tier-pro";

    body.innerHTML = `
      <div class="license-active">
        <div class="license-status">
          <span class="license-check">&#10003;</span>
          <span>${tierName} active</span>
        </div>
        <div class="license-key-display">${maskKey(license.key)}</div>
        <button class="btn-deactivate" id="deactivateBtn">Deactivate</button>
      </div>
    `;

    document.getElementById("deactivateBtn").addEventListener("click", () => {
      if (confirm("Deactivate your license? You can re-activate anytime.")) {
        chrome.runtime.sendMessage({ type: "DEACTIVATE_LICENSE" }, () => {
          userLevel = 0;
          renderLicenseSection(null);
          lastMatchName = null;
          loadData();
        });
      }
    });
  } else {
    badge.textContent = "Free";
    badge.className = "tier-badge tier-free";

    body.innerHTML = `
      <div class="license-form">
        <p class="license-hint">Have a license key? Enter it below to unlock Pro features.</p>
        <div class="license-input-row">
          <input type="text" id="licenseInput" class="license-input"
                 placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX"
                 spellcheck="false" autocomplete="off">
          <button class="btn-activate" id="activateBtn">Activate</button>
        </div>
        <div class="license-error" id="licenseError" style="display:none;"></div>
        <a href="https://fifaticketscout.com/#pricing" target="_blank" class="upgrade-link">
          Get a license &rarr;
        </a>
      </div>
    `;

    document.getElementById("activateBtn").addEventListener("click", handleActivate);
    document.getElementById("licenseInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter") handleActivate();
    });
  }
}

function maskKey(key) {
  if (key.length <= 8) return key;
  return key.substring(0, 8) + key.substring(8).replace(/[A-Z0-9]/gi, "*");
}

function handleActivate() {
  const input = document.getElementById("licenseInput");
  const errorEl = document.getElementById("licenseError");
  const btn = document.getElementById("activateBtn");
  const key = input.value.trim();

  if (!key) {
    errorEl.textContent = "Please enter a license key.";
    errorEl.style.display = "block";
    return;
  }

  btn.disabled = true;
  btn.textContent = "Verifying\u2026";
  errorEl.style.display = "none";

  chrome.runtime.sendMessage({ type: "ACTIVATE_LICENSE", licenseKey: key }, (resp) => {
    if (resp?.ok) {
      userLevel = resp.level;
      chrome.storage.local.get("license", (data) => {
        renderLicenseSection(data.license);
        lastMatchName = null;
        loadData();
      });
    } else {
      errorEl.textContent = resp?.error || "Verification failed.";
      errorEl.style.display = "block";
      btn.disabled = false;
      btn.textContent = "Activate";
    }
  });
}

// --- Alerts Tab ---

const SUPABASE_URL = "https://yaydpahqlqwesqdddgfi.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlheWRwYWhxbHF3ZXNxZGRkZ2ZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU5MDg1NDEsImV4cCI6MjA5MTQ4NDU0MX0.QQJuKz9Fnb_schlS6FEioMtyRvrJVBwAL71dzitZU-g";

let alertsTabLoaded = false;
let matchList = [];
let faceValueMap = {}; // match_number -> { cat1, cat2, cat3 }
let selectedAlertGames = new Map(); // match_number -> prefs
let alertFilters = { search: "", stages: new Set(["All"]), countries: new Set() };
let expandedDrawer = null; // match_number of currently open drawer
// Pick limit + per-pick lock state. Both come from the get-alerts response on
// every render so the server is the single source of truth for MAX_PICKS;
// fallback default is 3 if the server response hasn't loaded yet.
let maxPicks = 3;
let lockedMatchNumbers = new Set(); // match_numbers that came from saved config

function isPickLocked(matchNumber) {
  return lockedMatchNumbers.has(matchNumber);
}

function hasAnyUnlockedPick() {
  for (const pick of selectedAlertGames.values()) {
    if (!isPickLocked(pick.match_number)) return true;
  }
  return false;
}

// City → host country
const CITY_COUNTRY = {
  "Los Angeles": "USA", "NY / NJ": "USA", "Dallas": "USA", "Miami": "USA",
  "Atlanta": "USA", "Boston": "USA", "Houston": "USA", "Kansas City": "USA",
  "Philadelphia": "USA", "San Francisco": "USA", "Seattle": "USA",
  "Toronto": "CAN", "Vancouver": "CAN",
  "Mexico City": "MEX", "Guadalajara": "MEX", "Monterrey": "MEX",
};

function renderAlertsTab() {
  const container = document.getElementById("alertsContent");

  // Check tier
  if (userLevel < TIERS.PRO_WEB_ALERTS) {
    container.innerHTML = renderAlertsLocked();
    return;
  }

  // Already loaded? Just re-render with current state
  if (alertsTabLoaded) {
    loadSavedAlertConfig().then((config) => renderAlertsForm(container, config));
    return;
  }

  // Loading state
  container.innerHTML = `
    <div class="alerts-header">
      <h2>Alerts</h2>
      <p class="alerts-subtitle">Pick ${maxPicks} matches. We'll ping you when prices drop.</p>
    </div>
    <div class="alerts-msg">Loading matches&hellip;</div>
  `;

  // Load match list + face values + cloud config in parallel.
  // Cloud is the source of truth; local cache is a fallback when offline.
  Promise.all([fetchMatchList(), fetchFaceValues(), fetchAlertsFromCloud()]).then(([matches, faceValues, cloudConfig]) => {
    matchList = matches || [];
    faceValueMap = buildFaceValueMap(faceValues || []);

    if (cloudConfig?.ok) {
      // Canonical: overwrite local cache with the server copy
      chrome.storage.local.set({ alertConfigs: cloudConfig });
      if (cloudConfig.games?.length) {
        selectedAlertGames = new Map(
          cloudConfig.games.map((g) => [g.match_number, migratePickToNewShape(g)])
        );
      }
      alertsTabLoaded = true;
      renderAlertsForm(container, cloudConfig);
      return;
    }

    // Cloud fetch failed — fall back to whatever's in local cache and
    // surface an "offline" hint so the user knows they may be looking at
    // stale data.
    loadSavedAlertConfig().then((localConfig) => {
      if (localConfig?.games) {
        selectedAlertGames = new Map(
          localConfig.games.map((g) => [g.match_number, migratePickToNewShape(g)])
        );
      }
      alertsTabLoaded = true;
      renderAlertsForm(container, localConfig, { offline: true });
    });
  }).catch((err) => {
    container.innerHTML = `
      <div class="alerts-header"><h2>Alerts</h2></div>
      <div class="alerts-msg error">Could not load matches. Try again later.</div>
    `;
    console.log("[FIFA Ticket Scout] Alerts load error:", err);
  });
}

function fetchFaceValues() {
  return fetch(`${SUPABASE_URL}/rest/v1/face_values?select=match_number,category,face_value&order=match_number.asc`, {
    headers: {
      "apikey": SUPABASE_ANON_KEY,
      "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
    },
  }).then((r) => r.json());
}

function buildFaceValueMap(rows) {
  const map = {};
  for (const r of rows) {
    if (!map[r.match_number]) map[r.match_number] = {};
    map[r.match_number][`cat${r.category}`] = r.face_value;
  }
  return map;
}

function getFaceValueForCategory(matchNumber, category) {
  const fv = faceValueMap[matchNumber];
  if (!fv) return null;
  if (category === "any" || !category) {
    // cheapest cat
    const vals = [fv.cat1, fv.cat2, fv.cat3].filter((v) => v != null);
    return vals.length > 0 ? Math.min(...vals) : null;
  }
  if (category === "CAT 1") return fv.cat1;
  if (category === "CAT 2") return fv.cat2;
  if (category === "CAT 3") return fv.cat3;
  return null;
}

function renderAlertsLocked() {
  return `
    <div class="alerts-header">
      <h2>Alerts</h2>
      <p class="alerts-subtitle">Get notified when prices drop on the games that matter to you.</p>
    </div>
    <div class="alerts-locked">
      <div class="alerts-locked-icon">&#x1F512;</div>
      <div class="alerts-locked-title">Alerts is a Pro + Web + Alerts feature</div>
      <p class="alerts-locked-msg">
        Pick up to 3 games and we'll email you when prices drop below your target.
        Built for fans trying to get into the stadium with their family, not for flippers.
      </p>
      <a href="https://fifaticketscout.com/#pricing" target="_blank" class="btn-upgrade">
        Upgrade &mdash; choose PRO + WEB + ALERTS &rarr;
      </a>
    </div>
  `;
}

function fetchMatchList() {
  return fetch(`${SUPABASE_URL}/rest/v1/match_schedule?select=match_number,match_date,stage,city,home_team,away_team,matchup,performance_id&order=match_number.asc`, {
    headers: {
      "apikey": SUPABASE_ANON_KEY,
      "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
    },
  }).then((r) => r.json());
}

function loadSavedAlertConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get("alertConfigs", (data) => {
      resolve(data.alertConfigs || null);
    });
  });
}

// Pull the canonical alert config from Supabase via the get-alerts Edge
// Function. Returns the config on success, or null on any failure (network,
// auth, server). The caller is responsible for falling back to the local
// cache and rendering an offline state.
function fetchAlertsFromCloud() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "FETCH_ALERTS" }, (resp) => {
      if (chrome.runtime.lastError || !resp?.ok) {
        resolve(null);
        return;
      }
      resolve(resp);
    });
  });
}

function renderAlertsForm(container, savedConfig, opts) {
  // Pull MAX_PICKS from the server response (fallback to current value).
  // Build the per-pick lock set from the saved config — a pick is "locked"
  // if it was already in the saved config when this form rendered.
  if (typeof savedConfig?.maxPicks === "number") maxPicks = savedConfig.maxPicks;
  lockedMatchNumbers = new Set((savedConfig?.games || []).map((g) => g.match_number));

  const savedEmail = savedConfig?.email || "";
  const count = selectedAlertGames.size;
  const slotsAvailable = count < maxPicks;
  const hasUnlocked = hasAnyUnlockedPick();
  const offline = opts?.offline === true;

  container.innerHTML = `
    <div class="alerts-header">
      <h2>Alerts</h2>
      <p class="alerts-subtitle">Pick ${maxPicks} matches. We'll ping you when prices drop.</p>
      ${offline ? '<span class="offline-chip" title="Could not reach the server — showing the picks from your last successful save">&#9888; Offline &mdash; cached picks</span>' : ''}
    </div>
    ${slotsAvailable ? `
    <div class="alerts-warning">
      <strong>Choose your matches carefully.</strong> Once you hit the <strong>+</strong> button on a match and save, that pick is final &mdash; only the price threshold can change later.
    </div>
    ` : ''}

    ${!savedEmail ? `
    <div class="alerts-section">
      <div class="alerts-section-title">Email</div>
      <input type="email" id="alertsEmail" class="alerts-email-input" placeholder="you@example.com">
      <div class="alerts-helper">Where should we send your price drop alerts?</div>
    </div>
    ` : `
    <div class="alerts-section alerts-email-locked">
      <div class="alerts-section-title">Email</div>
      <div class="email-display">${escapeHtml(maskEmail(savedEmail))}
        <span class="lock-inline">&#x1F512;</span>
      </div>
      <div class="alerts-helper">Locked to your license.</div>
    </div>
    `}

    <!-- Your Picks -->
    <div class="picks-section">
      <div class="picks-header">
        <span class="picks-title">Your Picks</span>
        <span class="picks-counter">${count} of ${maxPicks}</span>
      </div>
      <div id="pickSlots"></div>
    </div>

    ${slotsAvailable ? `
    <!-- Browse -->
    <div class="alerts-browse">
      <input type="text" id="alertsSearch" class="alerts-search" placeholder="Search team, city, or stage..." value="${escapeHtml(alertFilters.search)}">
      <div class="filter-pills" id="stagePills"></div>
      <div class="filter-pills" id="countryPills"></div>
    </div>
    <div class="match-list-header" id="matchListHeader"></div>
    <div class="match-list" id="matchList"></div>
    ` : ""}

    <div id="alertsMsg"></div>

    <button class="btn-save-alerts" id="saveAlertsBtn" ${count === 0 ? "disabled" : ""}>
      ${hasUnlocked ? `Save my ${count} pick${count !== 1 ? "s" : ""}` : "Update Price Thresholds"}
    </button>
  `;

  renderPickSlots();
  if (slotsAvailable) {
    renderFilterPills();
    renderMatchList();
    document.getElementById("alertsSearch").addEventListener("input", (e) => {
      alertFilters.search = e.target.value;
      renderMatchList();
    });
  }
  document.getElementById("saveAlertsBtn").addEventListener("click", handleSaveAlerts);
}

function renderPickSlots() {
  const slotsEl = document.getElementById("pickSlots");
  const slots = Array.from({ length: maxPicks }, (_, i) => i + 1);
  const picks = Array.from(selectedAlertGames.values());

  slotsEl.innerHTML = slots.map((n) => {
    const pick = picks[n - 1];
    if (!pick) {
      return `<div class="pick-slot pick-slot-empty">+ Add pick ${n}</div>`;
    }
    const locked = isPickLocked(pick.match_number);
    const match = matchList.find((m) => m.match_number === pick.match_number);
    if (!match) return "";
    const teams = (match.home_team && match.away_team)
      ? `${match.home_team} vs ${match.away_team}`
      : (match.matchup || "TBD");
    const dateStr = match.match_date ? new Date(match.match_date + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "";
    const summary = summarizeThreshold(pick);
    const isExpanded = expandedDrawer === pick.match_number;

    return `
      <div class="pick-slot ${isExpanded ? 'expanded' : ''}" data-match="${pick.match_number}">
        <div class="pick-slot-header">
          <div class="pick-slot-info">
            <div class="pick-slot-teams">#${pick.match_number} &middot; ${escapeHtml(teams)} ${locked ? '<span class="lock-inline">&#x1F512;</span>' : ''}</div>
            <div class="pick-slot-meta">${escapeHtml(match.city || "")} &middot; ${escapeHtml(match.stage || "")} &middot; ${dateStr}</div>
            <div class="pick-summary">${summary}</div>
          </div>
          <button class="pick-edit-btn" data-edit="${pick.match_number}">${isExpanded ? 'Close' : 'Edit'}</button>
        </div>
        ${isExpanded ? renderThresholdDrawer(pick, locked) : ""}
      </div>
    `;
  }).join("");

  // Wire up edit buttons
  slotsEl.querySelectorAll(".pick-edit-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const matchNum = parseInt(btn.dataset.edit);
      expandedDrawer = expandedDrawer === matchNum ? null : matchNum;
      renderPickSlots();
    });
  });

  // Wire up drawer inputs
  wireThresholdDrawer();
}

// Normalize a saved game config into the current pref shape.
// Handles legacy { mode: "face" | "custom", threshold } entries.
function migratePickToNewShape(g) {
  if (g.thresholdMode) {
    return {
      ...g,
      percentOfFace: g.percentOfFace || 0,
      dollarOffset: g.dollarOffset || 0,
      absolute: g.absolute || 0,
    };
  }
  const base = {
    match_number: g.match_number,
    performance_id: g.performance_id || null,
    category: g.category || "any",
    seats: g.seats || 2,
    thresholdMode: "percent",
    percentOfFace: 0,
    dollarOffset: 0,
    absolute: 0,
  };
  if (g.mode === "face") return base;
  // Legacy "custom" with a fixed dollar threshold → absolute mode
  if (g.threshold && g.threshold > 0) {
    return { ...base, thresholdMode: "absolute", absolute: g.threshold };
  }
  return base;
}

// Compute effective dollar threshold from a pick's threshold settings.
// Returns null if face value required but not available.
function computeThresholdForPick(pick) {
  const mode = pick.thresholdMode || "percent";
  if (mode === "absolute") {
    return pick.absolute != null ? pick.absolute : null;
  }
  const fv = getFaceValueForCategory(pick.match_number, pick.category);
  if (fv == null) return null;
  if (mode === "dollarOffset") {
    const offset = pick.dollarOffset != null ? pick.dollarOffset : 0;
    return Math.max(0, Math.round(fv + offset));
  }
  // percent
  const pct = pick.percentOfFace != null ? pick.percentOfFace : 0;
  return Math.max(0, Math.round(fv * (1 + pct / 100)));
}

function summarizeThreshold(pick) {
  const seats = pick.seats || 2;
  const cat = pick.category === "any" ? "Any" : (pick.category || "Any");
  const mode = pick.thresholdMode || "percent";

  let head;
  if (mode === "absolute") {
    const abs = pick.absolute != null ? pick.absolute : 0;
    head = `&le;$${abs}`;
  } else if (mode === "dollarOffset") {
    const off = pick.dollarOffset || 0;
    if (off === 0) head = `&le;Face`;
    else if (off > 0) head = `&le;+$${off} vFace`;
    else head = `&le;-$${Math.abs(off)} vFace`;
  } else {
    const pct = pick.percentOfFace != null ? pick.percentOfFace : 0;
    if (pct === 0) head = `&le;Face`;
    else if (pct > 0) head = `&le;+${pct}% vFace`;
    else head = `&le;${pct}% vFace`;
  }
  return `${head} &middot; ${cat} &middot; ${seats}tix`;
}

function formatPercentLabel(pct) {
  if (pct === 0) return "Face";
  if (pct > 0) return `+${pct}%`;
  return `${pct}%`;
}

function formatDollarOffsetLabel(d) {
  if (d === 0) return "Face";
  if (d > 0) return `+$${d}`;
  return `-$${Math.abs(d)}`;
}

function formatAbsoluteLabel(d) {
  return `$${d}`;
}

function buildSliderExample(pick, _fv) {
  // Examples use a fixed $500 face value for easy mental math,
  // regardless of the actual match face value.
  const mode = pick.thresholdMode || "percent";
  const EXAMPLE_FV = 500;

  if (mode === "absolute") {
    const abs = pick.absolute != null ? pick.absolute : 0;
    return `Ignore face value, you'll be alerted when the price drops at or below $${abs}.`;
  }

  if (mode === "dollarOffset") {
    const off = pick.dollarOffset != null ? pick.dollarOffset : 0;
    const threshold = Math.max(0, EXAMPLE_FV + off);
    const offStr = off === 0 ? "$0" : off > 0 ? `+$${off}` : `-$${Math.abs(off)}`;
    return `If face value is $${EXAMPLE_FV}, at ${offStr}, you'll be alerted when the price drops at or below $${threshold}.`;
  }

  // percent
  const pct = pick.percentOfFace != null ? pick.percentOfFace : 0;
  const threshold = Math.max(0, Math.round(EXAMPLE_FV * (1 + pct / 100)));
  const pctStr = pct === 0 ? "0%" : pct > 0 ? `+${pct}%` : `${pct}%`;
  return `If face value is $${EXAMPLE_FV}, at ${pctStr}, you'll be alerted when the price drops at or below $${threshold}.`;
}

function isPickDeal(pick, fv) {
  const mode = pick.thresholdMode || "percent";
  if (mode === "percent") return (pick.percentOfFace || 0) <= 0;
  if (mode === "dollarOffset") return (pick.dollarOffset || 0) <= 0;
  if (mode === "absolute") return fv != null && (pick.absolute || 0) <= fv;
  return false;
}

function sliderConfigForMode(mode) {
  if (mode === "dollarOffset") {
    return { min: -500, max: 3000, step: 100, leftLabel: "-$500", midLabel: "Face", rightLabel: "+$3000" };
  }
  if (mode === "absolute") {
    return { min: 0, max: 5000, step: 50, leftLabel: "$0", midLabel: "", rightLabel: "$5000" };
  }
  return { min: -50, max: 300, step: 5, leftLabel: "-50%", midLabel: "Face", rightLabel: "+300%" };
}

function sliderValueForMode(pick) {
  const mode = pick.thresholdMode || "percent";
  if (mode === "dollarOffset") return pick.dollarOffset != null ? pick.dollarOffset : 0;
  if (mode === "absolute") return pick.absolute != null ? pick.absolute : 0;
  return pick.percentOfFace != null ? pick.percentOfFace : 0;
}

function sliderFillPct(value, min, max) {
  if (max === min) return 0;
  const p = ((value - min) / (max - min)) * 100;
  return Math.max(0, Math.min(100, p));
}

function sliderLabelForMode(pick) {
  const mode = pick.thresholdMode || "percent";
  if (mode === "dollarOffset") return formatDollarOffsetLabel(pick.dollarOffset || 0);
  if (mode === "absolute") return formatAbsoluteLabel(pick.absolute || 0);
  return formatPercentLabel(pick.percentOfFace || 0);
}

function renderThresholdDrawer(pick, locked) {
  const category = pick.category || "any";
  const seats = pick.seats || 2;
  const mode = pick.thresholdMode || "percent";
  const catFv = getFaceValueForCategory(pick.match_number, category);
  const example = buildSliderExample(pick, catFv);
  const isDeal = isPickDeal(pick, catFv);
  const cfg = sliderConfigForMode(mode);
  const val = sliderValueForMode(pick);
  const valLabel = sliderLabelForMode(pick);
  const fillPct = sliderFillPct(val, cfg.min, cfg.max);

  return `
    <div class="threshold-drawer" data-match="${pick.match_number}">
      <div class="drawer-label">Alert me when price is at or below</div>
      <div class="threshold-mode-pills">
        <button class="mode-pill ${mode === "percent" ? "active" : ""}" data-mode="percent">% vs Face</button>
        <button class="mode-pill ${mode === "dollarOffset" ? "active" : ""}" data-mode="dollarOffset">$ vs Face</button>
        <button class="mode-pill ${mode === "absolute" ? "active" : ""}" data-mode="absolute">Absolute $</button>
      </div>
      <div class="threshold-slider-wrap ${isDeal ? 'is-deal' : ''}">
        <div class="slider-value-display" id="sliderVal-${pick.match_number}">${valLabel}</div>
        <input type="range" class="threshold-slider" data-field="${mode}"
          min="${cfg.min}" max="${cfg.max}" step="${cfg.step}" value="${val}"
          style="--fill: ${fillPct}%">
        <div class="slider-labels">
          <span>${cfg.leftLabel}</span>
          <span class="slider-mid-label">${cfg.midLabel}</span>
          <span>${cfg.rightLabel}</span>
        </div>
        <div class="slider-example" id="sliderExample-${pick.match_number}">${escapeHtml(example)}</div>
      </div>

      <div class="drawer-label">Category</div>
      <div class="filter-pills drawer-cat-pills">
        <button class="filter-pill ${category === "any" ? "active" : ""}" data-cat="any">Any</button>
        <button class="filter-pill ${category === "CAT 1" ? "active" : ""}" data-cat="CAT 1">CAT 1</button>
        <button class="filter-pill ${category === "CAT 2" ? "active" : ""}" data-cat="CAT 2">CAT 2</button>
        <button class="filter-pill ${category === "CAT 3" ? "active" : ""}" data-cat="CAT 3">CAT 3</button>
      </div>

      <div class="drawer-label">Seats needed</div>
      <div class="stepper">
        <button class="step-btn" data-step="-1">&minus;</button>
        <span class="step-value">${seats}</span>
        <button class="step-btn" data-step="+1">+</button>
      </div>

      ${!locked ? `
      <div class="drawer-actions">
        <button class="drawer-remove" data-remove="${pick.match_number}">Remove pick</button>
      </div>
      ` : ""}
    </div>
  `;
}

function wireThresholdDrawer() {
  document.querySelectorAll(".threshold-drawer").forEach((drawer) => {
    const matchNum = parseInt(drawer.dataset.match);
    const prefs = selectedAlertGames.get(matchNum);
    if (!prefs) return;

    // Mode toggle pills
    drawer.querySelectorAll("[data-mode]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const nextMode = btn.dataset.mode;
        if (prefs.thresholdMode === nextMode) return;
        prefs.thresholdMode = nextMode;
        // Seed absolute with face value on first switch if unset
        if (nextMode === "absolute" && (prefs.absolute == null || prefs.absolute === 0)) {
          const fv = getFaceValueForCategory(matchNum, prefs.category);
          if (fv != null) prefs.absolute = fv;
        }
        selectedAlertGames.set(matchNum, prefs);
        renderPickSlots();
      });
    });

    // Slider (routes value to correct pref field based on mode)
    const slider = drawer.querySelector(".threshold-slider");
    const valEl = drawer.querySelector(`#sliderVal-${matchNum}`);
    const exampleEl = drawer.querySelector(`#sliderExample-${matchNum}`);
    const wrap = drawer.querySelector(".threshold-slider-wrap");
    if (slider) {
      slider.addEventListener("input", (e) => {
        e.stopPropagation();
        const v = parseInt(e.target.value);
        const mode = prefs.thresholdMode || "percent";
        if (mode === "dollarOffset") prefs.dollarOffset = v;
        else if (mode === "absolute") prefs.absolute = v;
        else prefs.percentOfFace = v;
        selectedAlertGames.set(matchNum, prefs);
        if (valEl) valEl.textContent = sliderLabelForMode(prefs);
        const fv = getFaceValueForCategory(matchNum, prefs.category);
        if (exampleEl) exampleEl.textContent = buildSliderExample(prefs, fv);
        if (wrap) wrap.classList.toggle("is-deal", isPickDeal(prefs, fv));
        const cfg = sliderConfigForMode(mode);
        slider.style.setProperty("--fill", sliderFillPct(v, cfg.min, cfg.max) + "%");
      });
      slider.addEventListener("change", () => renderPickSlots());
    }

    // Category pills
    drawer.querySelectorAll("[data-cat]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        prefs.category = btn.dataset.cat;
        selectedAlertGames.set(matchNum, prefs);
        renderPickSlots();
      });
    });

    // Stepper
    drawer.querySelectorAll(".step-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const delta = parseInt(btn.dataset.step);
        const next = Math.max(1, Math.min(6, (prefs.seats || 2) + delta));
        prefs.seats = next;
        selectedAlertGames.set(matchNum, prefs);
        renderPickSlots();
      });
    });

    // Remove
    drawer.querySelectorAll("[data-remove]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const mn = parseInt(btn.dataset.remove);
        selectedAlertGames.delete(mn);
        expandedDrawer = null;
        loadSavedAlertConfig().then((config) => {
          renderAlertsForm(document.getElementById("alertsContent"), config);
        });
      });
    });
  });
}

function renderFilterPills() {
  const stageEl = document.getElementById("stagePills");
  const countryEl = document.getElementById("countryPills");

  const stages = ["All", "Group", "R32", "R16", "QF", "SF", "Bronze", "Final"];
  stageEl.innerHTML = stages.map((s) => {
    const active = alertFilters.stages.has(s) ? "active" : "";
    return `<button class="filter-pill ${active}" data-stage="${s}">${s}</button>`;
  }).join("");

  const countries = ["USA", "CAN", "MEX"];
  countryEl.innerHTML = countries.map((c) => {
    const active = alertFilters.countries.has(c) ? "active" : "";
    return `<button class="filter-pill ${active}" data-country="${c}">${c}</button>`;
  }).join("");

  stageEl.querySelectorAll("[data-stage]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const stage = btn.dataset.stage;
      if (stage === "All") {
        alertFilters.stages = new Set(["All"]);
      } else {
        alertFilters.stages.delete("All");
        if (alertFilters.stages.has(stage)) alertFilters.stages.delete(stage);
        else alertFilters.stages.add(stage);
        if (alertFilters.stages.size === 0) alertFilters.stages = new Set(["All"]);
      }
      renderFilterPills();
      renderMatchList();
    });
  });

  countryEl.querySelectorAll("[data-country]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const country = btn.dataset.country;
      if (alertFilters.countries.has(country)) alertFilters.countries.delete(country);
      else alertFilters.countries.add(country);
      renderFilterPills();
      renderMatchList();
    });
  });
}

function filterMatches() {
  const q = alertFilters.search.toLowerCase().trim();
  return matchList.filter((m) => {
    // Stage filter
    if (!alertFilters.stages.has("All")) {
      const matchesStage = Array.from(alertFilters.stages).some((s) => {
        if (s === "Group") return (m.stage || "").startsWith("Group ");
        return m.stage === s;
      });
      if (!matchesStage) return false;
    }
    // Country filter
    if (alertFilters.countries.size > 0) {
      const country = CITY_COUNTRY[m.city];
      if (!country || !alertFilters.countries.has(country)) return false;
    }
    // Search filter
    if (q) {
      const hay = [
        m.home_team, m.away_team, m.matchup, m.city, m.stage,
      ].filter(Boolean).join(" ").toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function renderMatchList() {
  const listEl = document.getElementById("matchList");
  const headerEl = document.getElementById("matchListHeader");
  if (!listEl || !headerEl) return;

  const filtered = filterMatches();
  const count = selectedAlertGames.size;
  const canAdd = count < maxPicks;

  headerEl.innerHTML = `Showing ${filtered.length} of ${matchList.length}`;

  listEl.innerHTML = filtered.map((m) => {
    const isSelected = selectedAlertGames.has(m.match_number);
    const teams = (m.home_team && m.away_team)
      ? `${m.home_team} vs ${m.away_team}`
      : (m.matchup || "TBD");
    const dateStr = m.match_date ? new Date(m.match_date + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "";
    const fv = faceValueMap[m.match_number];
    const cheapestFv = fv ? Math.min(...[fv.cat1, fv.cat2, fv.cat3].filter((v) => v != null)) : null;
    const fvStr = cheapestFv != null ? `$${cheapestFv}` : "";

    const btnState = isSelected ? "added" : (canAdd ? "can-add" : "disabled");
    const btnSymbol = isSelected ? "&#10003;" : "+";
    const btnTitle = isSelected ? "Added" : (canAdd ? "Add to picks" : "Remove a pick first");

    return `
      <div class="match-list-row ${isSelected ? 'selected' : ''}" data-match="${m.match_number}">
        <div class="match-row-info">
          <div class="match-row-teams">#${m.match_number} &middot; ${escapeHtml(teams)}</div>
          <div class="match-row-meta">${escapeHtml(m.city || "")} &middot; ${escapeHtml(m.stage || "")} &middot; ${dateStr}${fvStr ? ' &middot; ' + fvStr : ''}</div>
        </div>
        <button class="match-row-add ${btnState}" data-add="${m.match_number}" title="${btnTitle}">${btnSymbol}</button>
      </div>
    `;
  }).join("");

  listEl.querySelectorAll(".match-row-add").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const matchNum = parseInt(btn.dataset.add);
      if (selectedAlertGames.has(matchNum)) return;
      if (selectedAlertGames.size >= maxPicks) return;
      addGameSelection(matchNum);
    });
  });
}

function addGameSelection(matchNumber) {
  const match = matchList.find((m) => m.match_number === matchNumber);
  selectedAlertGames.set(matchNumber, {
    match_number: matchNumber,
    performance_id: match?.performance_id || null,
    category: "any",
    seats: 2,
    thresholdMode: "percent",
    percentOfFace: 0,
    dollarOffset: 0,
    absolute: 0,
  });
  // Re-render form
  loadSavedAlertConfig().then((config) => {
    renderAlertsForm(document.getElementById("alertsContent"), config);
  });
}

function maskEmail(email) {
  const [local, domain] = email.split("@");
  if (!domain) return email;
  const masked = local.length > 2
    ? local[0] + "•".repeat(Math.min(local.length - 2, 5)) + local.slice(-1)
    : local;
  return `${masked}@${domain}`;
}

function validEmail(email) {
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!re.test(email)) return false;
  if (/[,;\s]/.test(email)) return false;
  return true;
}

function handleSaveAlerts() {
  const msgEl = document.getElementById("alertsMsg");
  const btn = document.getElementById("saveAlertsBtn");
  const emailInput = document.getElementById("alertsEmail");

  loadSavedAlertConfig().then((config) => {
    const savedEmail = config?.email || "";
    const email = savedEmail || (emailInput ? emailInput.value.trim() : "");

    // Email validation only when there's no saved one yet
    if (!savedEmail && !validEmail(email)) {
      msgEl.innerHTML = '<div class="alerts-msg error">Please enter a single valid email address.</div>';
      return;
    }

    if (selectedAlertGames.size === 0) {
      msgEl.innerHTML = '<div class="alerts-msg error">Pick at least one game.</div>';
      return;
    }

    // Confirm only when we're about to lock at least one NEW pick.
    // Threshold-only updates (all picks already locked) skip the dialog.
    if (hasAnyUnlockedPick()) {
      const confirmed = confirm(
        "Lock in these matches?\n\n" +
        "To keep alerts for true fans, the matches you pick are permanent.\n\n" +
        "You can still adjust price, category, and seats anytime — just not the matches themselves."
      );
      if (!confirmed) return;
    }

    // Compute effective threshold per game from the threshold mode/value
    const games = Array.from(selectedAlertGames.values()).map((prefs) => {
      const threshold = computeThresholdForPick(prefs);
      return {
        match_number: prefs.match_number,
        performance_id: prefs.performance_id,
        threshold: threshold || 0,
        category: prefs.category || "any",
        seats: prefs.seats || 2,
        thresholdMode: prefs.thresholdMode || "percent",
        percentOfFace: prefs.percentOfFace || 0,
        dollarOffset: prefs.dollarOffset || 0,
        absolute: prefs.absolute || 0,
      };
    });

    // Validate each game has a positive threshold
    for (const g of games) {
      if (!g.threshold || g.threshold <= 0) {
        msgEl.innerHTML = `<div class="alerts-msg error">Set a price threshold for match ${g.match_number} (face value may not be available yet).</div>`;
        return;
      }
    }

    btn.disabled = true;
    btn.textContent = "Saving...";
    msgEl.innerHTML = "";

    chrome.runtime.sendMessage(
      { type: "SAVE_ALERTS", payload: { email, games } },
      (resp) => {
        if (resp?.ok) {
          msgEl.innerHTML = '<div class="alerts-msg success">Saved. We\'re watching these for you.</div>';
          alertsTabLoaded = false; // force reload on next open
          setTimeout(() => renderAlertsTab(), 600);
        } else {
          msgEl.innerHTML = `<div class="alerts-msg error">${resp?.error || "Save failed. Try again."}</div>`;
          btn.disabled = false;
          btn.textContent = hasAnyUnlockedPick() ? "Save my picks" : "Update Price Thresholds";
        }
      }
    );
  });
}

// --- Scan All Sections ---

function startScan() {
  getCurrentTabUrl().then((url) => {
    const perfIdMatch = url.match(/perfId=(\d+)/);
    const tabPerfId = perfIdMatch ? perfIdMatch[1] : null;

    chrome.storage.local.get(null, (data) => {
      if (!data?.games) {
        alert("No game data yet. Browse to a match seat map first.");
        return;
      }

      const gameIds = Object.keys(data.games);
      const activeId = (tabPerfId && data.games[tabPerfId]) ? tabPerfId : gameIds[0];
      const game = data.games[activeId];

      if (!game?.productId || !activeId) {
        alert("Browse to a match seat map first so the extension can detect the game IDs.");
        return;
      }

      scanStartTime = 0;
      scanElapsed = 0;
      lastPillPct = 0;
      lastMatchName = null;
      chrome.runtime.sendMessage({ type: "CLEAR_DATA" }, () => {
        document.getElementById("dashboard").style.display = "none";
        document.getElementById("noData").style.display = "block";
        document.getElementById("liveBadge").style.display = "none";
        document.getElementById("emptyTitle").textContent = "Data cleared";
        document.getElementById("emptyHint").textContent = "Click refresh in your browser to repull the data.";
        document.getElementById("emptyAction").style.display = "none";
      });
    });
  });
}

function updateScanProgress(perfId, completed, total, status, eta) {
  // Only update progress for the currently displayed game
  if (perfId && currentPerfId && perfId !== currentPerfId) return;
  const pct = Math.round((completed / total) * 100);
  document.getElementById("progressFill").style.width = pct + "%";

  // Header badge: SCANNING while in progress, SCANNED once done.
  const badgeText = document.getElementById("liveBadgeText");
  if (badgeText) {
    badgeText.textContent = (status === "done" || pct >= 100) ? "SCANNED" : "SCANNING";
  }

  // Track scan timing
  if (pct > 0 && scanStartTime === 0) scanStartTime = Date.now();
  if (status === "done" || status === "captcha") scanElapsed = Date.now() - scanStartTime;

  // Update pill progress in match header
  const snapped = status === "done" ? 100 : Math.floor(pct / 10) * 10;
  lastPillPct = snapped;
  const pillFill = document.getElementById("scanPillFill");
  const pillText = document.getElementById("scanPillText");
  if (pillFill) {
    pillFill.style.width = snapped + "%";
  }
  if (pillText) {
    if (status === "done") {
      pillText.textContent = formatElapsed(scanElapsed);
    } else {
      pillText.textContent = snapped + "%";
    }
  }

  if (status === "captcha") {
    // Show rate limit warning in the empty state area
    document.getElementById("noData").style.display = "block";
    document.getElementById("emptyTitle").textContent = "Rate limited";
    document.getElementById("emptyHint").textContent = "Bot detection was triggered. Wait about 5 minutes, then refresh the page to try again. Try a slower scan speed next time.";
    document.getElementById("emptyAction").style.display = "none";

    lastPillPct = 100;
    if (pillFill) {
      pillFill.style.width = "100%";
      pillFill.style.background = "#d44040";
    }
  } else if (status === "done") {
    document.getElementById("progressText").textContent = "Done!";
    const btn = document.getElementById("scanBtn");
    btn.disabled = false;
    document.getElementById("scanBtnText").textContent = "Scan Complete!";
    setTimeout(() => {
      document.getElementById("scanBtnText").textContent = "Clear & Rescan";
      document.getElementById("scanProgress").style.display = "none";
    }, 3000);
  } else {
    let label = pct + "%";
    if (eta != null && eta > 0) {
      label += eta >= 60
        ? " · ~" + Math.ceil(eta / 60) + "m left"
        : " · ~" + eta + "s left";
    }
    document.getElementById("progressText").textContent = label;
  }
}
